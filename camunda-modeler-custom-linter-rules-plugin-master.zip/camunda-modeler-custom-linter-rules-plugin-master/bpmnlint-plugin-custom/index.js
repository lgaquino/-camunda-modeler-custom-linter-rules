module.exports = {
  configs: {
    recommended: {
      rules: {
        'no-manual-task': 'error'
      }
    }
  }
}