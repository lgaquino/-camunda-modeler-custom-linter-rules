'use strict';

module.exports = {
  name: 'Linter - Custom Rules',
  script: './dist/client.js'
};
